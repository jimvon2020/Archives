function a() {return 5;}
a()
